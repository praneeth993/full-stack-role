# Loan_managing
The application demonstrates full-stack integration, showcasing frontend and backend skills along with the ability to work with databases like MongoDB. By submitting this, the candidate has shown their capability in connecting the form submission to a functional dashboard for managing loan data.
